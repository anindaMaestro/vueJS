<template>
    <header>
        
  <!-- <h1>S’inscrire sur Jobbiz</h1> -->
  <h1>{{ title }}</h1>
      
      <table class="table table-striped">
        <thead>
          <tr>
            <th id="Nom">Nom</th>
            <th>Prenom</th>
          </tr>
          <tr>
 <!-- v-model is a directive that binds the value of a form element to a v-model prop of a component
 prop is a property of a component
 component is a Vue instance -->
          <th><input type="text" v-model="Nom"/></th>
          <th><input type="text" v-model="Prenom"/></th>
        </tr>
        </thead>

        <!-- -------------------------- -->

        <thead>
          <tr>
            <th id="Email">Email</th>
            
          </tr>
          <tr>
 
          <th><input type="text" v-model="Email"/></th>
          
        </tr>
        </thead>

        <!-- ----------------------------------- -->

                <thead>
          <tr>
            <th id="Numero">Numero</th>
            
          </tr>
          <tr>
 
          <th><input type="text" v-model="Numero"/></th>
          
        </tr>
        </thead>

        <!-- ----------------------------------------- -->

        <thead>
          <tr>
            <th id="Mot-de-passe">Mot-de-passe</th>
            
          </tr>
          <tr>
 
          <th><input type="text" v-model="MotDePasse"/></th>
          
        </tr>
        </thead>

        <!-- ----------------------------------- -->

        <thead>
          <tr>
            <th id="Confirmation-Mot-de-passe">Confirmation mot-de-passe</th>
            
          </tr>
          <tr>
 
          <th><input type="text" v-model="ConfirmationMotDePasse"/></th>
          
        </tr>
        </thead>
        <!-- ------------------------------------ -->

        <button>S'inscrire</button>
        
        
        
        </table>


  
    </header>
</template>

<script>
    export default {
        name: 'Header',
        data() {
            return {
                Nom: '',
                Prenom: '',
                Email: '',
                Numero: '',
                MotDePasse: '',
                ConfirmationMotDePasse: ''

        
    }
        },
        methods: {
            submit() {
                console.log(this.Nom);
                console.log(this.Prenom);
                console.log(this.Email);
                console.log(this.Numero);
                console.log(this.MotDePasse);
                console.log(this.ConfirmationMotDePasse);
            }
</script>

// scoped means that anything in here would be just for this particular component
<style scoped>
    header {
        /* flex because we are gonna have a button to toggle the add form */
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    /* we are gonna take this up to App.vue */

</style>