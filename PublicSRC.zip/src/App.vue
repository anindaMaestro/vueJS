<template>
  <div class="container">
<h1>S’inscrire sur Jobbiz</h1>
<table class="table table-striped">
        <thead>
          <tr>
            <th id="Nom">Nom</th>
            <th>Prenom</th>
          </tr>
          <tr>
 <!-- v-model is a directive that binds the value of a form element to a v-model prop of a component
 prop is a property of a component
 component is a Vue instance -->
          <th><input type="text" v-model="Nom"/></th>
          <th><input type="text" v-model="Prenom"/></th>
        </tr>
        </thead>

        <!-- -------------------------- -->

        <thead>
          <tr>
            <th id="Email">Email</th>
            
          </tr>
          <tr>
 
          <th><input type="text" v-model="Email"/></th>
          
        </tr>
        </thead>

        <!-- ----------------------------------- -->

                <thead>
          <tr>
            <th id="Numero">Numero</th>
            
          </tr>
          <tr>
 
          <th><input type="text" v-model="Numero"/></th>
          
        </tr>
        </thead>

        <!-- ----------------------------------------- -->

        <thead>
          <tr>
            <th id="Mot-de-passe">Mot-de-passe</th>
            
          </tr>
          <tr>
 
          <th><input type="text" v-model="MotDePasse"/></th>
          
        </tr>
        </thead>

        <!-- ----------------------------------- -->

        <thead>
          <tr>
            <th id="Confirmation-Mot-de-passe">Confirmation mot-de-passe</th>
            
          </tr>
          <tr>
 
          <th><input type="text" v-model="ConfirmationMotDePasse"/></th>
          
        </tr>
        </thead>
        <!-- ------------------------------------ -->

        <button>S'inscrire</button>
        
        
        
        </table>

  </div>
  
   
</template>

// taking the styles of the Header.vue in here and hence we are gonna use import
import Header from './components/Header.vue'
// now, the idea is to register the component in the Vue instance


<script>
// import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  components: {
    

  }
}
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400&display=swap');
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
body {
  font-family: 'Poppins', sans-serif;
}
.container {
  max-width: 500px;
  margin: 30px auto;
  overflow: auto;
  min-height: 300px;
  border: 1px solid steelblue;
  padding: 30px;
  border-radius: 5px;
}
.btn {
  display: inline-block;
  background: #000;
  color: #fff;
  border: none;
  padding: 10px 20px;
  margin: 5px;
  border-radius: 5px;
  cursor: pointer;
  text-decoration: none;
  font-size: 15px;
  font-family: inherit;
}
.btn:focus {
  outline: none;
}
.btn:active {
  transform: scale(0.98);
}
.btn-block {
  display: block;
  width: 100%;
}
</style>


